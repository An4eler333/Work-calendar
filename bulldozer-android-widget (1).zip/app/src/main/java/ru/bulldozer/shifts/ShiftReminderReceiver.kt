package ru.bulldozer.shifts

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ShiftReminderReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED) {
            NotificationHelper.rescheduleUpcomingAlarms(context)
            ShiftWidgetProvider.updateAllWidgets(context)
            return
        }
        if (action == ACTION_SHIFT_REMINDER) {
            val title = intent.getStringExtra(EXTRA_TITLE) ?: "🚜 Бульдозер 2/2"
            val body = intent.getStringExtra(EXTRA_BODY) ?: "Напоминание о смене"
            val tag = intent.getStringExtra(EXTRA_TAG) ?: "shift-reminder"
            NotificationHelper.showNotification(context, title, body, tag)
            NotificationHelper.rescheduleUpcomingAlarms(context)
            ShiftWidgetProvider.updateAllWidgets(context)
        }
    }

    companion object {
        const val ACTION_SHIFT_REMINDER = "ru.bulldozer.shifts.ACTION_SHIFT_REMINDER"
        const val EXTRA_TITLE = "extra_title"
        const val EXTRA_BODY = "extra_body"
        const val EXTRA_TAG = "extra_tag"
    }
}
