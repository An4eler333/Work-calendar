package ru.bulldozer.shifts

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.ZoneId

object NotificationHelper {
    const val CHANNEL_ID = "bulldozer_shift_reminders"
    private const val PREFS_NAME = "bulldozer_notify_prefs"
    private const val KEY_ENABLED = "notify_enabled"
    private const val KEY_BEFORE_MIN = "notify_before_min"
    private const val KEY_START = "notify_start"
    private const val KEY_END = "notify_end"
    private const val MAX_SCHEDULED_DAYS = 7

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            if (manager.getNotificationChannel(CHANNEL_ID) != null) return
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Напоминания о сменах",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Уведомления о начале и окончании смен 2/2"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 220, 120, 220)
            }
            manager.createNotificationChannel(channel)
        }
    }

    fun hasPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun showNotification(context: Context, title: String, body: String, tag: String) {
        ensureChannel(context)
        if (!hasPermission(context)) return

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPending = PendingIntent.getActivity(
            context,
            tag.hashCode(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_shift_day)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setVibrate(longArrayOf(0, 220, 120, 220))
            .setContentIntent(contentPending)

        try {
            NotificationManagerCompat.from(context).notify(tag.hashCode(), builder.build())
        } catch (_: SecurityException) {
            // Permission revoked by user
        }
    }

    fun saveConfigAndReschedule(
        context: Context,
        enabled: Boolean,
        beforeMin: Int,
        notifyStart: Boolean,
        notifyEnd: Boolean
    ) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, enabled)
            .putInt(KEY_BEFORE_MIN, beforeMin)
            .putBoolean(KEY_START, notifyStart)
            .putBoolean(KEY_END, notifyEnd)
            .apply()
        rescheduleUpcomingAlarms(context)
    }

    fun rescheduleUpcomingAlarms(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean(KEY_ENABLED, false)
        val beforeMin = prefs.getInt(KEY_BEFORE_MIN, 15).coerceAtLeast(0)
        val notifyStart = prefs.getBoolean(KEY_START, true)
        val notifyEnd = prefs.getBoolean(KEY_END, true)

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        // Cancel previous scheduled slots (up to 16 slots)
        for (slot in 0..16) {
            val cancelStart = PendingIntent.getBroadcast(
                context,
                3000 + slot,
                Intent(context, ShiftReminderReceiver::class.java).setAction(ShiftReminderReceiver.ACTION_SHIFT_REMINDER),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (cancelStart != null) alarmManager.cancel(cancelStart)

            val cancelEnd = PendingIntent.getBroadcast(
                context,
                4000 + slot,
                Intent(context, ShiftReminderReceiver::class.java).setAction(ShiftReminderReceiver.ACTION_SHIFT_REMINDER),
                PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
            )
            if (cancelEnd != null) alarmManager.cancel(cancelEnd)
        }

        if (!enabled || !hasPermission(context)) return

        ensureChannel(context)
        val nowMs = System.currentTimeMillis()
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now()

        for (offset in -1..MAX_SCHEDULED_DAYS) {
            val d = today.plusDays(offset.toLong())
            val entry = ShiftCalculator.getShiftEntryForDate(context, d)
            if (!ShiftCalculator.isWorkShiftType(entry.type) || entry.status == "missed") continue

            val (startDt, endDt) = ShiftCalculator.shiftWindowForDate(d, entry.type)
            val label = ShiftCalculator.shortLabel(entry.type)
            val isNight = entry.type == "night"
            val iconEmoji = if (isNight) "🌙" else "☀️"
            val slot = offset + 1

            if (notifyStart) {
                val triggerAt = startDt.minusMinutes(beforeMin.toLong()).atZone(zone).toInstant().toEpochMilli()
                if (triggerAt > nowMs + 5_000L) {
                    val title = if (beforeMin > 0) {
                        "$iconEmoji Через $beforeMin мин: $label смена"
                    } else {
                        "$iconEmoji Начало смены: $label"
                    }
                    val startStr = if (isNight) "20:00" else "08:00"
                    val body = "Начало в $startStr (${ShiftCalculator.formatHoursPlain(entry.hours)})"
                    scheduleSingleAlarm(context, alarmManager, 3000 + slot, triggerAt, title, body, "start-$d")
                }
            }

            if (notifyEnd) {
                val triggerAt = endDt.atZone(zone).toInstant().toEpochMilli()
                if (triggerAt > nowMs + 5_000L) {
                    val title = "✅ Конец смены: $label"
                    val body = "Смена (${ShiftCalculator.formatHoursPlain(entry.hours)}) завершена. Хорошего отдыха!"
                    scheduleSingleAlarm(context, alarmManager, 4000 + slot, triggerAt, title, body, "end-$d")
                }
            }
        }
    }

    private fun scheduleSingleAlarm(
        context: Context,
        alarmManager: AlarmManager,
        requestCode: Int,
        triggerAtMs: Long,
        title: String,
        body: String,
        tag: String
    ) {
        val intent = Intent(context, ShiftReminderReceiver::class.java).apply {
            action = ShiftReminderReceiver.ACTION_SHIFT_REMINDER
            putExtra(ShiftReminderReceiver.EXTRA_TITLE, title)
            putExtra(ShiftReminderReceiver.EXTRA_BODY, body)
            putExtra(ShiftReminderReceiver.EXTRA_TAG, tag)
        }
        val pi = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMs, pi)
    }
}
