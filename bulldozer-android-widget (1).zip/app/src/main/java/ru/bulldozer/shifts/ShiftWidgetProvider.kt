package ru.bulldozer.shifts

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import androidx.core.content.ContextCompat

class ShiftWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        var anyActive = false
        for (appWidgetId in appWidgetIds) {
            val isActive = updateWidget(context, appWidgetManager, appWidgetId)
            if (isActive) anyActive = true
        }
        scheduleNextRefresh(context, anyActive)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return
        if (
            action == ACTION_REFRESH_WIDGET ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED ||
            action == Intent.ACTION_DATE_CHANGED ||
            action == Intent.ACTION_USER_PRESENT
        ) {
            updateAllWidgets(context)
        }
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        alarmManager.cancel(createRefreshPendingIntent(context))
    }

    companion object {
        const val ACTION_REFRESH_WIDGET = "ru.bulldozer.shifts.ACTION_REFRESH_WIDGET"

        fun updateAllWidgets(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, ShiftWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            if (ids.isEmpty()) return

            var anyActive = false
            for (id in ids) {
                if (updateWidget(context, manager, id)) {
                    anyActive = true
                }
            }
            scheduleNextRefresh(context, anyActive)
        }

        private fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ): Boolean {
            val state = ShiftCalculator.computeWidgetState(context)
            val views = RemoteViews(context.packageName, R.layout.widget_shift_4x2)

            views.setTextViewText(R.id.widget_date, state.dateLabel)
            views.setTextViewText(R.id.widget_time_pill, state.timePill)
            views.setTextViewText(R.id.widget_shift_title, state.title)
            views.setTextViewText(R.id.widget_shift_subtitle, state.subtitle)
            views.setTextViewText(R.id.widget_shift_subtitle_alt, state.subtitleAlt)
            views.setTextViewText(R.id.widget_progress_pct, "${state.progress}%")
            views.setTextViewText(R.id.widget_left_label, state.leftLabel)
            views.setTextViewText(R.id.widget_left_value, state.leftValue)
            views.setTextViewText(R.id.widget_right_label, state.rightLabel)
            views.setTextViewText(R.id.widget_right_value, state.rightValue)

            // Show live pulsing beacon when shift is currently active
            views.setViewVisibility(
                R.id.widget_live_flipper,
                if (state.isShiftActiveNow) View.VISIBLE else View.GONE
            )

            // Theme-matched gradient card background
            val cardBgRes = when (state.theme) {
                WidgetTheme.NIGHT, WidgetTheme.SLEEP -> R.drawable.widget_card_bg_night
                WidgetTheme.DAY -> R.drawable.widget_card_bg_day
                WidgetTheme.WORKED -> R.drawable.widget_card_bg_worked
                WidgetTheme.OFF -> R.drawable.widget_card_bg_off
            }
            views.setInt(R.id.widget_root, "setBackgroundResource", cardBgRes)

            // Icon container + vector icon
            val iconBgRes = when (state.theme) {
                WidgetTheme.NIGHT, WidgetTheme.SLEEP -> R.drawable.widget_icon_bg_night
                WidgetTheme.DAY -> R.drawable.widget_icon_bg_day
                WidgetTheme.WORKED -> R.drawable.widget_icon_bg_worked
                WidgetTheme.OFF -> R.drawable.widget_icon_bg_off
            }
            val iconRes = when (state.theme) {
                WidgetTheme.NIGHT -> R.drawable.ic_shift_night
                WidgetTheme.DAY -> R.drawable.ic_shift_day
                WidgetTheme.SLEEP -> R.drawable.ic_shift_sleep
                WidgetTheme.WORKED -> R.drawable.ic_shift_worked
                WidgetTheme.OFF -> R.drawable.ic_shift_off
            }
            views.setInt(R.id.widget_icon_container, "setBackgroundResource", iconBgRes)
            views.setImageViewResource(R.id.widget_shift_icon, iconRes)

            // Safely toggle themed progress bar without unsupported RemoteViews method calls
            val isIndigo = state.theme == WidgetTheme.NIGHT || state.theme == WidgetTheme.SLEEP
            val isEmerald = state.theme == WidgetTheme.WORKED
            val isAmber = !isIndigo && !isEmerald

            views.setViewVisibility(R.id.widget_progress_amber, if (isAmber) View.VISIBLE else View.GONE)
            views.setViewVisibility(R.id.widget_progress_indigo, if (isIndigo) View.VISIBLE else View.GONE)
            views.setViewVisibility(R.id.widget_progress_emerald, if (isEmerald) View.VISIBLE else View.GONE)

            views.setProgressBar(R.id.widget_progress_amber, 100, state.progress, false)
            views.setProgressBar(R.id.widget_progress_indigo, 100, state.progress, false)
            views.setProgressBar(R.id.widget_progress_emerald, 100, state.progress, false)

            val rightValueColor = when (state.theme) {
                WidgetTheme.WORKED -> ContextCompat.getColor(context, R.color.accent_emerald)
                WidgetTheme.NIGHT, WidgetTheme.SLEEP -> ContextCompat.getColor(context, R.color.accent_indigo)
                else -> ContextCompat.getColor(context, R.color.accent_amber)
            }
            views.setTextColor(R.id.widget_right_value, rightValueColor)

            // Tap card -> open calendar app
            val launchIntent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingLaunch = PendingIntent.getActivity(
                context,
                0,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pendingLaunch)

            // Tap time pill -> force instant refresh of widget counters
            views.setOnClickPendingIntent(R.id.widget_time_pill, createRefreshPendingIntent(context))

            appWidgetManager.updateAppWidget(appWidgetId, views)
            return state.isShiftActiveNow
        }

        private fun createRefreshPendingIntent(context: Context): PendingIntent {
            val intent = Intent(context, ShiftWidgetProvider::class.java).apply {
                action = ACTION_REFRESH_WIDGET
            }
            return PendingIntent.getBroadcast(
                context,
                1001,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        private fun scheduleNextRefresh(context: Context, isShiftActiveNow: Boolean) {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
            val intervalMs = if (isShiftActiveNow) 60_000L else 15 * 60_000L
            val triggerAt = SystemClock.elapsedRealtime() + intervalMs
            alarmManager.set(
                AlarmManager.ELAPSED_REALTIME,
                triggerAt,
                createRefreshPendingIntent(context)
            )
        }
    }
}
