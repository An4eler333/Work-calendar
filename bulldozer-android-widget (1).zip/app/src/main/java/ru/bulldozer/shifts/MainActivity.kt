package ru.bulldozer.shifts

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    companion object {
        private const val APP_URL = "https://ais-pre-dhogcaqszgzn2jvaxwtm4l-903054593678.europe-west2.run.app"
        private const val REQ_POST_NOTIFICATIONS = 2001
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        NotificationHelper.ensureChannel(this)

        window.statusBarColor = Color.parseColor("#0B0D10")
        window.navigationBarColor = Color.parseColor("#0B0D10")

        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#0B0D10"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.cacheMode = if (isNetworkAvailable()) {
                WebSettings.LOAD_DEFAULT
            } else {
                WebSettings.LOAD_CACHE_ELSE_NETWORK
            }
            addJavascriptInterface(
                AndroidWidgetBridge(applicationContext, this@MainActivity),
                "AndroidWidgetBridge"
            )
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    return false
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    view?.evaluateJavascript(
                        """
                        (function() {
                          try {
                            var d = localStorage.getItem('bulldozer_shift_data_v4');
                            if (d && window.AndroidWidgetBridge) {
                              window.AndroidWidgetBridge.syncShiftData(d);
                            }
                            var c = localStorage.getItem('bulldozer_config_v4');
                            if (c && window.AndroidWidgetBridge) {
                              var cfg = JSON.parse(c);
                              window.AndroidWidgetBridge.syncNotifyConfig(
                                Boolean(cfg.notifyEnabled),
                                Number(cfg.notifyBeforeMin || 0),
                                cfg.notifyStart !== false,
                                cfg.notifyEnd !== false
                              );
                            }
                            if (typeof updateNotifyUI === 'function') updateNotifyUI();
                          } catch (e) {}
                        })();
                        """.trimIndent(),
                        null
                    )
                }
            }
        }

        setContentView(webView)
        webView.loadUrl(APP_URL)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })

        requestNotificationPermissionIfNeeded()
        ShiftWidgetProvider.updateAllWidgets(this)
    }

    override fun onResume() {
        super.onResume()
        ShiftWidgetProvider.updateAllWidgets(this)
        if (::webView.isInitialized) {
            webView.evaluateJavascript("if (typeof updateNotifyUI === 'function') updateNotifyUI();", null)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_POST_NOTIFICATIONS) {
            val granted = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
            val statusStr = if (granted) "granted" else "denied"
            if (::webView.isInitialized) {
                webView.post {
                    webView.evaluateJavascript(
                        """
                        (function() {
                          if (window.__androidNotifyPermResolve) {
                            var r = window.__androidNotifyPermResolve;
                            window.__androidNotifyPermResolve = null;
                            r('$statusStr');
                          }
                          if (typeof updateNotifyUI === 'function') updateNotifyUI();
                        })();
                        """.trimIndent(),
                        null
                    )
                }
            }
            if (granted) {
                NotificationHelper.rescheduleUpcomingAlarms(this)
            }
        }
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (!NotificationHelper.hasPermission(this)) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    REQ_POST_NOTIFICATIONS
                )
            }
        }
    }

    class AndroidWidgetBridge(
        private val appContext: Context,
        private val activity: MainActivity
    ) {
        @JavascriptInterface
        fun syncShiftData(json: String) {
            if (json.isBlank()) return
            ShiftCalculator.saveSyncedJson(appContext, json)
            ShiftWidgetProvider.updateAllWidgets(appContext)
            NotificationHelper.rescheduleUpcomingAlarms(appContext)
        }

        @JavascriptInterface
        fun hasNotificationSupport(): Boolean = true

        @JavascriptInterface
        fun getNotificationPermission(): String {
            return if (NotificationHelper.hasPermission(appContext)) "granted" else "default"
        }

        @JavascriptInterface
        fun requestNotificationPermission() {
            activity.runOnUiThread {
                activity.requestNotificationPermissionIfNeeded()
            }
        }

        @JavascriptInterface
        fun sendNotification(title: String, body: String, tag: String) {
            NotificationHelper.showNotification(appContext, title, body, tag)
        }

        @JavascriptInterface
        fun syncNotifyConfig(
            enabled: Boolean,
            beforeMin: Int,
            notifyStart: Boolean,
            notifyEnd: Boolean
        ) {
            NotificationHelper.saveConfigAndReschedule(
                appContext,
                enabled,
                beforeMin,
                notifyStart,
                notifyEnd
            )
        }
    }
}
