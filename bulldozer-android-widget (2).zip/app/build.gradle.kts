plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.bulldozer.shifts"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.bulldozer.shifts"
        minSdk = 26
        targetSdk = 35
        val ciVersionCode = System.getenv("APP_VERSION_CODE")?.toIntOrNull() ?: 2
        val ciVersionName = System.getenv("APP_VERSION_NAME")?.takeIf { it.isNotBlank() } ?: "1.1.0"
        versionCode = ciVersionCode
        versionName = ciVersionName
    }

    val releaseKeystorePath = System.getenv("KEYSTORE_PATH")
    val releaseKeystoreFile = if (!releaseKeystorePath.isNullOrBlank()) file(releaseKeystorePath) else null

    signingConfigs {
        if (releaseKeystoreFile != null && releaseKeystoreFile.exists()) {
            create("release") {
                storeFile = releaseKeystoreFile
                storePassword = System.getenv("KEYSTORE_PASSWORD") ?: ""
                keyAlias = System.getenv("KEY_ALIAS") ?: ""
                keyPassword = System.getenv("KEY_PASSWORD") ?: ""
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (releaseKeystoreFile != null && releaseKeystoreFile.exists()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.webkit:webkit:1.11.0")
}
