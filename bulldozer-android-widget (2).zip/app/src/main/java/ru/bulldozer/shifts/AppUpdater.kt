package ru.bulldozer.shifts

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

object AppUpdater {

    private const val RELEASES_LATEST_URL =
        "https://api.github.com/repos/An4eler333/Work-calendar/releases/latest"
    private const val PREFS_NAME = "app_updater_prefs"
    private const val KEY_LAST_CHECK_MS = "last_check_ms"
    private const val KEY_DISMISSED_TAG = "dismissed_tag"
    private const val AUTO_CHECK_INTERVAL_MS = 30L * 60L * 1000L

    private val mainHandler = Handler(Looper.getMainLooper())
    private val isChecking = AtomicBoolean(false)
    private var pendingInstallApk: File? = null

    data class ReleaseInfo(
        val tagName: String,
        val versionStr: String,
        val title: String,
        val notes: String,
        val apkUrl: String,
        val apkSizeBytes: Long
    )

    fun getInstalledVersionName(context: Context): String {
        return try {
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(
                    context.packageName,
                    PackageManager.PackageInfoFlags.of(0)
                )
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(context.packageName, 0)
            }
            info.versionName ?: "1.1.0"
        } catch (_: Exception) {
            "1.1.0"
        }
    }

    fun onActivityResumed(activity: Activity) {
        val pending = pendingInstallApk ?: return
        if (!pending.exists()) {
            pendingInstallApk = null
            return
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || activity.packageManager.canRequestPackageInstalls()) {
            pendingInstallApk = null
            launchApkInstaller(activity, pending)
        }
    }

    fun checkForUpdate(activity: Activity, manual: Boolean) {
        val appContext = activity.applicationContext
        val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        if (!manual) {
            val lastCheck = prefs.getLong(KEY_LAST_CHECK_MS, 0L)
            if (System.currentTimeMillis() - lastCheck < AUTO_CHECK_INTERVAL_MS) {
                return
            }
        }

        if (!isChecking.compareAndSet(false, true)) {
            if (manual) {
                mainHandler.post {
                    Toast.makeText(activity, "Проверка обновлений уже выполняется...", Toast.LENGTH_SHORT).show()
                }
            }
            return
        }

        if (manual) {
            mainHandler.post {
                Toast.makeText(activity, "Проверяем обновления на GitHub...", Toast.LENGTH_SHORT).show()
            }
        }

        Thread {
            try {
                prefs.edit().putLong(KEY_LAST_CHECK_MS, System.currentTimeMillis()).apply()
                val release = fetchLatestRelease()
                if (release == null) {
                    if (manual) {
                        mainHandler.post {
                            if (!activity.isFinishing) {
                                Toast.makeText(
                                    activity,
                                    "Релизов APK на GitHub пока нет",
                                    Toast.LENGTH_LONG
                                ).show()
                            }
                        }
                    }
                    return@Thread
                }

                val currentVer = getInstalledVersionName(appContext)
                if (compareVersions(release.versionStr, currentVer) <= 0) {
                    if (manual) {
                        mainHandler.post {
                            if (!activity.isFinishing) {
                                Toast.makeText(
                                    activity,
                                    "Установлена актуальная версия v$currentVer",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    }
                    return@Thread
                }

                val dismissedTag = prefs.getString(KEY_DISMISSED_TAG, null)
                if (!manual && dismissedTag == release.tagName) {
                    return@Thread
                }

                mainHandler.post {
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        showUpdatePromptDialog(activity, release, currentVer)
                    }
                }
            } catch (_: Exception) {
                if (manual) {
                    mainHandler.post {
                        if (!activity.isFinishing) {
                            Toast.makeText(
                                activity,
                                "Не удалось проверить обновления (проверьте интернет)",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            } finally {
                isChecking.set(false)
            }
        }.start()
    }

    private fun fetchLatestRelease(): ReleaseInfo? {
        val conn = openHttpWithRedirects(RELEASES_LATEST_URL, acceptJson = true)
        return try {
            val code = conn.responseCode
            if (code == HttpURLConnection.HTTP_NOT_FOUND) {
                return null
            }
            if (code !in 200..299) {
                throw IllegalStateException("HTTP $code")
            }
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val json = JSONObject(body)
            val tagName = json.optString("tag_name", "").trim()
            val versionStr = normalizeVersion(tagName)
            val name = json.optString("name", tagName).ifBlank { tagName }
            val notes = json.optString("body", "").trim()
            val assets = json.optJSONArray("assets") ?: return null

            var apkUrl = ""
            var apkSize = 0L
            for (i in 0 until assets.length()) {
                val asset = assets.optJSONObject(i) ?: continue
                val assetName = asset.optString("name", "")
                if (assetName.endsWith(".apk", ignoreCase = true)) {
                    apkUrl = asset.optString("browser_download_url", "")
                    apkSize = asset.optLong("size", 0L)
                    break
                }
            }

            if (apkUrl.isBlank() || versionStr.isBlank()) return null

            ReleaseInfo(
                tagName = tagName,
                versionStr = versionStr,
                title = name,
                notes = notes,
                apkUrl = apkUrl,
                apkSizeBytes = apkSize
            )
        } finally {
            conn.disconnect()
        }
    }

    private fun showUpdatePromptDialog(
        activity: Activity,
        release: ReleaseInfo,
        currentVer: String
    ) {
        val sizeText = if (release.apkSizeBytes > 0) {
            val mb = release.apkSizeBytes / (1024.0 * 1024.0)
            String.format("Размер: %.1f МБ\n\n", mb)
        } else {
            ""
        }
        val notesBlock = if (release.notes.isNotBlank()) {
            release.notes.take(400)
        } else {
            "Доступна новая сборка приложения и виджета 4×2."
        }

        val message = "Текущая версия: v$currentVer\nНовая версия: v${release.versionStr}\n$sizeText$notesBlock"

        AlertDialog.Builder(activity)
            .setTitle("Доступно обновление APK")
            .setMessage(message)
            .setPositiveButton("Обновить сейчас") { _, _ ->
                startDownloadAndInstall(activity, release)
            }
            .setNegativeButton("Позже") { _, _ ->
                activity.applicationContext
                    .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putString(KEY_DISMISSED_TAG, release.tagName)
                    .apply()
            }
            .show()
    }

    private fun startDownloadAndInstall(activity: Activity, release: ReleaseInfo) {
        val cancelled = AtomicBoolean(false)
        val density = activity.resources.displayMetrics.density
        val padH = (24 * density).toInt()
        val padV = (16 * density).toInt()

        val container = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(padH, padV, padH, (8 * density).toInt())
        }

        val statusText = TextView(activity).apply {
            text = "Подключение к серверу..."
            textSize = 14f
            setPadding(0, 0, 0, (12 * density).toInt())
        }

        val progressBar = ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            isIndeterminate = release.apkSizeBytes <= 0L
        }

        container.addView(statusText)
        container.addView(progressBar)

        val dialog = AlertDialog.Builder(activity)
            .setTitle("Загрузка v${release.versionStr}")
            .setView(container)
            .setCancelable(false)
            .setNegativeButton("Отмена") { d, _ ->
                cancelled.set(true)
                d.dismiss()
            }
            .show()

        Thread {
            var conn: HttpURLConnection? = null
            try {
                val updatesDir = File(activity.cacheDir, "updates")
                if (updatesDir.exists()) {
                    updatesDir.listFiles()?.forEach { it.delete() }
                } else {
                    updatesDir.mkdirs()
                }
                val targetApk = File(updatesDir, "bulldozer-update-${release.versionStr}.apk")

                conn = openHttpWithRedirects(release.apkUrl, acceptJson = false)
                val code = conn.responseCode
                if (code !in 200..299) {
                    throw IllegalStateException("HTTP $code")
                }

                val totalBytes = if (conn.contentLengthLong > 0) conn.contentLengthLong else release.apkSizeBytes
                BufferedInputStream(conn.inputStream).use { input ->
                    FileOutputStream(targetApk).use { output ->
                        val buffer = ByteArray(16 * 1024)
                        var downloaded = 0L
                        var lastUiUpdate = 0L
                        while (true) {
                            if (cancelled.get()) {
                                targetApk.delete()
                                return@Thread
                            }
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            downloaded += read

                            val now = System.currentTimeMillis()
                            if (now - lastUiUpdate > 120) {
                                lastUiUpdate = now
                                val dlMb = downloaded / (1024.0 * 1024.0)
                                mainHandler.post {
                                    if (!dialog.isShowing) return@post
                                    if (totalBytes > 0) {
                                        val pct = ((downloaded * 100L) / totalBytes).toInt().coerceIn(0, 100)
                                        val totalMb = totalBytes / (1024.0 * 1024.0)
                                        progressBar.isIndeterminate = false
                                        progressBar.progress = pct
                                        statusText.text = String.format("Скачано %.1f / %.1f МБ (%d%%)", dlMb, totalMb, pct)
                                    } else {
                                        statusText.text = String.format("Скачано %.1f МБ...", dlMb)
                                    }
                                }
                            }
                        }
                        output.flush()
                    }
                }

                if (cancelled.get() || !targetApk.exists() || targetApk.length() < 100_000L) {
                    targetApk.delete()
                    throw IllegalStateException("Повреждённый файл обновления")
                }

                mainHandler.post {
                    if (dialog.isShowing) dialog.dismiss()
                    if (!activity.isFinishing && !activity.isDestroyed) {
                        installApkOrRequestPermission(activity, targetApk)
                    }
                }
            } catch (_: Exception) {
                if (!cancelled.get()) {
                    mainHandler.post {
                        if (dialog.isShowing) dialog.dismiss()
                        if (!activity.isFinishing) {
                            Toast.makeText(
                                activity,
                                "Ошибка загрузки обновления",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                    }
                }
            } finally {
                conn?.disconnect()
            }
        }.start()
    }

    private fun installApkOrRequestPermission(activity: Activity, apkFile: File) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !activity.packageManager.canRequestPackageInstalls()) {
            pendingInstallApk = apkFile
            AlertDialog.Builder(activity)
                .setTitle("Разрешение на установку")
                .setMessage(
                    "Чтобы «Бульдозер 2/2» мог устанавливать скачанные обновления прямо из приложения, включите тумблер «Разрешить из этого источника»."
                )
                .setPositiveButton("Открыть настройки") { _, _ ->
                    val intent = Intent(
                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:${activity.packageName}")
                    )
                    activity.startActivity(intent)
                }
                .setNegativeButton("Отмена") { _, _ ->
                    pendingInstallApk = null
                }
                .show()
            return
        }

        launchApkInstaller(activity, apkFile)
    }

    private fun launchApkInstaller(activity: Activity, apkFile: File) {
        try {
            val uri = FileProvider.getUriForFile(
                activity,
                "${activity.packageName}.fileprovider",
                apkFile
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            activity.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(
                activity,
                "Не удалось запустить установщик APK",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun openHttpWithRedirects(startUrl: String, acceptJson: Boolean): HttpURLConnection {
        var currentUrl = startUrl
        for (hop in 0 until 6) {
            val conn = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 15000
                readTimeout = 30000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "BulldozerShiftsApp")
                if (acceptJson) {
                    setRequestProperty("Accept", "application/vnd.github+json")
                }
            }
            val code = conn.responseCode
            if (code in listOf(301, 302, 303, 307, 308)) {
                val location = conn.getHeaderField("Location")
                conn.disconnect()
                if (location.isNullOrBlank()) {
                    throw IllegalStateException("Empty redirect location")
                }
                currentUrl = URL(URL(currentUrl), location).toString()
                continue
            }
            return conn
        }
        throw IllegalStateException("Too many redirects")
    }

    fun normalizeVersion(raw: String): String {
        return raw.trim().removePrefix("v").removePrefix("V").substringBefore("+")
    }

    fun compareVersions(a: String, b: String): Int {
        val pa = normalizeVersion(a).split(".", "-", "_").map { it.toIntOrNull() ?: 0 }
        val pb = normalizeVersion(b).split(".", "-", "_").map { it.toIntOrNull() ?: 0 }
        val maxLen = maxOf(pa.size, pb.size)
        for (i in 0 until maxLen) {
            val va = pa.getOrElse(i) { 0 }
            val vb = pb.getOrElse(i) { 0 }
            if (va != vb) return va.compareTo(vb)
        }
        return 0
    }
}
