package ru.bulldozer.shifts

import android.content.Context
import org.json.JSONObject
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Locale

data class ShiftEntry(
    val type: String,
    val hours: Double,
    val status: String
)

enum class WidgetTheme {
    DAY,
    NIGHT,
    SLEEP,
    OFF,
    WORKED
}

data class WidgetUiState(
    val dateLabel: String,
    val timePill: String,
    val title: String,
    val subtitle: String,
    val progress: Int,
    val leftLabel: String,
    val leftValue: String,
    val rightLabel: String,
    val rightValue: String,
    val theme: WidgetTheme,
    val isShiftActiveNow: Boolean
)

object ShiftCalculator {
    private const val PREFS_NAME = "bulldozer_widget_prefs"
    private const val KEY_SYNCED_JSON = "synced_shift_json"

    private val ANCHOR_DATE: LocalDate = LocalDate.of(2026, 11, 18)
    private const val ANCHOR_STEP = 4 // 1-я Ночная

    private val RU_LOCALE = Locale("ru", "RU")
    private val DATE_FORMATTER = DateTimeFormatter.ofPattern("EEE, d MMMM", RU_LOCALE)
    private val SHORT_DATE_FORMATTER = DateTimeFormatter.ofPattern("d MMM", RU_LOCALE)
    private val KEY_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE

    private val MONTHS_GENITIVE = arrayOf(
        "января", "февраля", "марта", "апреля", "мая", "июня",
        "июля", "августа", "сентября", "октября", "ноября", "декабря"
    )
    private val WEEKDAYS_SHORT = arrayOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")

    fun saveSyncedJson(context: Context, json: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_SYNCED_JSON, json)
            .apply()
    }

    private fun loadSyncedShifts(context: Context): Map<String, ShiftEntry> {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_SYNCED_JSON, null) ?: return emptyMap()
        return try {
            val root = JSONObject(raw)
            val shiftsObj = root.optJSONObject("shifts") ?: return emptyMap()
            val map = HashMap<String, ShiftEntry>(shiftsObj.length())
            val keys = shiftsObj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val item = shiftsObj.optJSONObject(key) ?: continue
                map[key] = ShiftEntry(
                    type = item.optString("type", "off"),
                    hours = item.optDouble("hours", 11.5),
                    status = item.optString("status", "auto")
                )
            }
            map
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun cycleShiftForDate(date: LocalDate): ShiftEntry {
        val diff = ChronoUnit.DAYS.between(ANCHOR_DATE, date).toInt()
        var step = (ANCHOR_STEP + (diff % 8)) % 8
        if (step < 0) step += 8
        return when (step) {
            0, 1 -> ShiftEntry("day", 11.5, "auto")
            4, 5 -> ShiftEntry("night", 11.5, "auto")
            6 -> ShiftEntry("sleep", 0.0, "auto")
            else -> ShiftEntry("off", 0.0, "auto")
        }
    }

    private fun getShiftForDate(date: LocalDate, synced: Map<String, ShiftEntry>): ShiftEntry {
        val key = date.format(KEY_FORMATTER)
        return synced[key] ?: cycleShiftForDate(date)
    }

    private fun isWorkType(type: String): Boolean {
        return type == "day" || type == "night" || type == "holiday" || type == "extra"
    }

    private fun titleForType(type: String): String = when (type) {
        "day" -> "Дневная смена"
        "night" -> "Ночная смена"
        "holiday" -> "Праздничная смена"
        "extra" -> "Подработка"
        "sleep" -> "Отсыпной"
        "vacation" -> "Отпуск"
        "sick" -> "Больничный"
        else -> "Выходной"
    }

    private fun shortTypeLabel(type: String): String = when (type) {
        "day" -> "Дневная"
        "night" -> "Ночная"
        "holiday" -> "Праздничная"
        "extra" -> "Подработка"
        else -> "Смена"
    }

    private fun shiftWindow(date: LocalDate, type: String): Pair<LocalDateTime, LocalDateTime> {
        val isNight = type == "night"
        val start = if (isNight) {
            LocalDateTime.of(date, LocalTime.of(20, 0))
        } else {
            LocalDateTime.of(date, LocalTime.of(8, 0))
        }
        val end = if (isNight) {
            LocalDateTime.of(date.plusDays(1), LocalTime.of(8, 0))
        } else {
            LocalDateTime.of(date, LocalTime.of(20, 0))
        }
        return start to end
    }

    private fun formatRussianDate(date: LocalDate): String {
        val dow = WEEKDAYS_SHORT[date.dayOfWeek.value - 1]
        val month = MONTHS_GENITIVE[date.monthValue - 1]
        return "$dow, ${date.dayOfMonth} $month"
    }

    private fun formatHoursNumber(hours: Double): String {
        return if (hours % 1.0 == 0.0) {
            "${hours.toInt()} ч"
        } else {
            String.format(RU_LOCALE, "%.1f ч", hours).replace('.', ',')
        }
    }

    private fun formatDurationHm(duration: Duration): String {
        val totalMinutes = maxOf(0L, duration.toMinutes())
        val h = totalMinutes / 60L
        val m = totalMinutes % 60L
        return String.format(RU_LOCALE, "%d ч %02d м", h, m)
    }

    private data class NextShiftInfo(
        val date: LocalDate,
        val entry: ShiftEntry,
        val start: LocalDateTime
    )

    private fun findNextWorkShift(now: LocalDateTime, synced: Map<String, ShiftEntry>): NextShiftInfo? {
        val today = now.toLocalDate()
        for (offset in 0..10) {
            val d = today.plusDays(offset.toLong())
            val entry = getShiftForDate(d, synced)
            if (!isWorkType(entry.type) || entry.status == "missed") continue
            val (start, _) = shiftWindow(d, entry.type)
            if (start.isAfter(now)) {
                return NextShiftInfo(d, entry, start)
            }
        }
        return null
    }

    fun computeWidgetState(context: Context, now: LocalDateTime = LocalDateTime.now()): WidgetUiState {
        val synced = loadSyncedShifts(context)
        val today = now.toLocalDate()
        val dateLabel = formatRussianDate(today)

        // 1. Check yesterday's overnight night shift (20:00 yesterday .. 08:00 today)
        val yesterday = today.minusDays(1)
        val yEntry = getShiftForDate(yesterday, synced)
        var activeDate = today
        var activeEntry = getShiftForDate(today, synced)
        var isFromYesterday = false

        if (yEntry.type == "night" && yEntry.status != "missed") {
            val (yStart, yEnd) = shiftWindow(yesterday, yEntry.type)
            if (!now.isBefore(yStart) && !now.isAfter(yEnd)) {
                activeDate = yesterday
                activeEntry = yEntry
                isFromYesterday = true
            }
        }

        val nextShift = findNextWorkShift(now, synced)

        if (isWorkType(activeEntry.type)) {
            if (activeEntry.status == "missed") {
                val nextLabel = nextShift?.let {
                    "${it.date.format(SHORT_DATE_FORMATTER)}, ${if (it.entry.type == "night") "20:00" else "08:00"}"
                } ?: "По графику"
                val nextIn = nextShift?.let { formatDurationHm(Duration.between(now, it.start)) } ?: "—"
                return WidgetUiState(
                    dateLabel = dateLabel,
                    timePill = "Невыход",
                    title = "${shortTypeLabel(activeEntry.type)} — невыход",
                    subtitle = "Часы не засчитаны",
                    progress = 0,
                    leftLabel = "СЛЕД. СМЕНА",
                    leftValue = nextLabel,
                    rightLabel = "ЧЕРЕЗ",
                    rightValue = nextIn,
                    theme = WidgetTheme.OFF,
                    isShiftActiveNow = false
                )
            }

            val (start, end) = shiftWindow(activeDate, activeEntry.type)
            val isNight = activeEntry.type == "night"
            val timeWindowStr = if (isNight) "20:00 – 08:00" else "08:00 – 20:00"
            val hoursStr = formatHoursNumber(if (activeEntry.hours > 0) activeEntry.hours else 11.5)

            // Active right now
            if (!now.isBefore(start) && !now.isAfter(end)) {
                val totalMin = maxOf(1L, Duration.between(start, end).toMinutes())
                val elapsed = Duration.between(start, now)
                val remaining = Duration.between(now, end)
                val pct = ((elapsed.toMinutes() * 100L) / totalMin).toInt().coerceIn(0, 100)

                return WidgetUiState(
                    dateLabel = if (isFromYesterday) "$dateLabel (ночь)" else dateLabel,
                    timePill = timeWindowStr,
                    title = titleForType(activeEntry.type),
                    subtitle = "Смена $hoursStr",
                    progress = pct,
                    leftLabel = "ПРОШЛО",
                    leftValue = formatDurationHm(elapsed),
                    rightLabel = "ОСТАЛОСЬ",
                    rightValue = formatDurationHm(remaining),
                    theme = if (isNight) WidgetTheme.NIGHT else WidgetTheme.DAY,
                    isShiftActiveNow = true
                )
            }

            // Upcoming today
            if (now.isBefore(start)) {
                val untilStart = Duration.between(now, start)
                return WidgetUiState(
                    dateLabel = dateLabel,
                    timePill = timeWindowStr,
                    title = titleForType(activeEntry.type),
                    subtitle = "Смена $hoursStr",
                    progress = 0,
                    leftLabel = "НАЧАЛО",
                    leftValue = "Сегодня, ${if (isNight) "20:00" else "08:00"}",
                    rightLabel = "ДО ВЫХОДА",
                    rightValue = formatDurationHm(untilStart),
                    theme = if (isNight) WidgetTheme.NIGHT else WidgetTheme.DAY,
                    isShiftActiveNow = false
                )
            }

            // Already finished today
            val nextLabel = nextShift?.let {
                val stTime = if (it.entry.type == "night") "20:00" else "08:00"
                "${it.date.format(SHORT_DATE_FORMATTER)}, $stTime"
            } ?: "По графику"
            val nextIn = nextShift?.let { formatDurationHm(Duration.between(now, it.start)) } ?: "—"
            return WidgetUiState(
                dateLabel = dateLabel,
                timePill = timeWindowStr,
                title = "${shortTypeLabel(activeEntry.type)} завершена",
                subtitle = "Отработано $hoursStr",
                progress = 100,
                leftLabel = "СЛЕД. СМЕНА",
                leftValue = nextLabel,
                rightLabel = "ЧЕРЕЗ",
                rightValue = nextIn,
                theme = WidgetTheme.WORKED,
                isShiftActiveNow = false
            )
        }

        // Non-working day (off / sleep / vacation / sick)
        val isSleep = activeEntry.type == "sleep"
        val subtitle = when (activeEntry.type) {
            "sleep" -> "Отдых после ночной"
            "vacation" -> "Отпуск по графику"
            "sick" -> "Больничный лист"
            else -> "Смен по графику нет"
        }
        val nextTitle = nextShift?.let {
            val stTime = if (it.entry.type == "night") "20:00" else "08:00"
            "${shortTypeLabel(it.entry.type)} • ${it.date.format(SHORT_DATE_FORMATTER)} $stTime"
        } ?: "По графику 2/2"
        val nextIn = nextShift?.let { formatDurationHm(Duration.between(now, it.start)) } ?: "—"

        return WidgetUiState(
            dateLabel = dateLabel,
            timePill = "Выходной",
            title = titleForType(activeEntry.type),
            subtitle = subtitle,
            progress = 0,
            leftLabel = "СЛЕД. СМЕНА",
            leftValue = nextTitle,
            rightLabel = "ЧЕРЕЗ",
            rightValue = nextIn,
            theme = if (isSleep) WidgetTheme.SLEEP else WidgetTheme.OFF,
            isShiftActiveNow = false
        )
    }
}
