package ru.bulldozer.shifts

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    companion object {
        private const val APP_URL = "https://ais-pre-dhogcaqszgzn2jvaxwtm4l-903054593678.europe-west2.run.app"
        private const val REQ_POST_NOTIFICATIONS = 2001
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.parseColor("#0B0D10")
        window.navigationBarColor = Color.parseColor("#0B0D10")

        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#0B0D10"))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.cacheMode = if (isNetworkAvailable()) {
                WebSettings.LOAD_DEFAULT
            } else {
                WebSettings.LOAD_CACHE_ELSE_NETWORK
            }
            addJavascriptInterface(AndroidWidgetBridge(applicationContext), "AndroidWidgetBridge")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView?,
                    request: WebResourceRequest?
                ): Boolean {
                    return false
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    // Pull latest shifts from localStorage so widget stays synced
                    view?.evaluateJavascript(
                        """
                        (function() {
                          try {
                            var d = localStorage.getItem('bulldozer_shift_data_v4');
                            if (d && window.AndroidWidgetBridge) {
                              window.AndroidWidgetBridge.syncShiftData(d);
                            }
                          } catch (e) {}
                        })();
                        """.trimIndent(),
                        null
                    )
                }
            }
        }

        setContentView(webView)
        webView.loadUrl(APP_URL)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    finish()
                }
            }
        })

        requestNotificationPermissionIfNeeded()
        ShiftWidgetProvider.updateAllWidgets(this)
    }

    override fun onResume() {
        super.onResume()
        ShiftWidgetProvider.updateAllWidgets(this)
    }

    private fun isNetworkAvailable(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    REQ_POST_NOTIFICATIONS
                )
            }
        }
    }

    class AndroidWidgetBridge(private val appContext: Context) {
        @JavascriptInterface
        fun syncShiftData(json: String) {
            if (json.isBlank()) return
            ShiftCalculator.saveSyncedJson(appContext, json)
            ShiftWidgetProvider.updateAllWidgets(appContext)
        }
    }
}
