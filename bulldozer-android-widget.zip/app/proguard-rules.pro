-keepclassmembers class ru.bulldozer.shifts.MainActivity$AndroidWidgetBridge {
    @android.webkit.JavascriptInterface <methods>;
}
